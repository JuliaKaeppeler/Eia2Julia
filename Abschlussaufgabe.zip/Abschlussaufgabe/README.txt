Hallo Jogi Löw!

ZIP-Ordner entpacken:
Entpacken Sie den ZIP-Ordner, in dem sie mit einem rechts-klick auf den ZIP-Ordner klicken.
Anschließend extrahieren Sie diesen und laden die Datei soccer.html im Browser.

Spielanleitung:
Wählen Sie zuerst die Farben der beiden Teams aus. Danach wählen Sie die Geschwindigkeit und Präzision,
mit Hilfe von Slidern können Sie die Geschwindigkeit zwischen einem min. Wert und einem max. Wert wählen.
Drücken Sie auf den Button "Start game" und schon kann das Spiel beginnen.
Per Mausklick können Sie den Ball an eine beliebige Position schießen. Der Spieler, der am nächsten
am Ball ist, hat diesen angenommen. Versuchen Sie Ihr Glück und schießen Sie ein Tor.
Welcher Spieler gerade am Ball ist und den Punktestand, sehen Sie oben rechts. 
Außerdem können sie oben rechts aus den beiden Teams, einen jeweiligen Spieler anzeigen lassen. D.h. Sie
können seine Spieler-Referenzen wie: Trickot-Nummer, Trickot-Farbe, Geschwindigkeit, Präzision,
sowie die Position (X und Y) auf dem Spielfeld sehen. Zusätzlich können Sie mit Hilfe des darunter liegenden
Buttons, einen Spieler vom Spielfeld entfernen. Möchten Sie etwas Musik hören? Dann klicken sie eine
beliebige Taste. Viel Spaß!
